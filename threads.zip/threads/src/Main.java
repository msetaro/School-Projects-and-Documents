public class Main {

    public static void main(String[] args) {

        MyThread mt = new MyThread();
        mt.start();       //tells JVM to start the thread we just created - start executes run()

        MyThread mt2 = new MyThread();
        mt2.start();

        MyThread mt3 = new MyThread();
        mt3.start();

        MyThread mt4 = new MyThread();
        mt4.start();

        MyThread mt5 = new MyThread();
        mt5.start();
    }
}

class MyThread extends Thread {
    //need to implement the run() method
    public void run() {
        int num = 0;
        //print ints from 0 to 9
        for (int i = 0; i < 10; i++) {
            num += 2;
            System.out.println( Thread.currentThread().getId() + ":  " + i + "  --  " + num);
            try{
                Thread.sleep(1);
            }catch(InterruptedException e){

            }

        }
    }
}




