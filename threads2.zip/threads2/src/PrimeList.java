public class PrimeList extends Thread {
//prints primes numbers btwn 400 and 3000
    @Override
    public void run() {

        final int lower = 400;
        final int upper = 3000;
        for ( int i = lower; i <= upper; i++) {
            if (isPrime(i)) {
                System.out.println( i );
            }
        }
    }

    private boolean isPrime( int num ) {
        int factor = 2;
        while( num % factor != 0) {
            factor++;
        }
        return num == factor;
    }


}
