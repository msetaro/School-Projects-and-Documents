import javax.naming.Name;

public class Main extends Thread{

    public static void main(String[] args) {
        /*
         *             MAX_PRIORITY == 10
         *             MIN_PRIORITY == 1
         *             No priority assigned:
         *                  default == 5 / NORM_PRIORITY
         */

        //thread for thanksgiving
        Runnable happyThanks = new HappyT();
        Thread thread1 = new Thread( happyThanks );
        thread1.setPriority(4);
        thread1.start();

        //thread for prime
        PrimeList prime = new PrimeList();
        prime.start();      // because the PrimeList class extends Thread, not implements runnable

        //thread for name message
        NameMessage yo = new NameMessage();
        yo.setPriority(Thread.MAX_PRIORITY);
        yo.start();
    }
}
