
public class DisplayMsg implements Runnable {
    private String mmsg;

    public DisplayMsg( String mmsg ){
        this.mmsg = mmsg;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++){
            System.out.println( mmsg );
        }
    }
}
