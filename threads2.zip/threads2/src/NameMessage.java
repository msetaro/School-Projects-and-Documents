import javax.swing.*;
import java.util.*;

public class NameMessage extends Thread {

    @Override
    public void run() {
        //using gui
        //String name = JOptionPane.showInputDialog(null, "Please enter your name: ");

        //using scanner in console
        Scanner mySCN = new Scanner( System.in );
        System.out.println("Hi, who are you?");
        String name = mySCN.nextLine();
        System.out.println("Happy Thanksgiving, " + name + "!!");
    }
}
