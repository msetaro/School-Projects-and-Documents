
public class Countr extends Thread {

    @Override
    public void run() {
        //prints #'s from 0 to 19
        for (int i = 0; i < 20; i++ ){
            System.out.println( i );

            if (i == 8) {
                try {
                    sleep(3);
                }
                catch (InterruptedException e) {

                }
            }

        }
    }


}
