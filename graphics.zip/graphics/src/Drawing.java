import java.awt.*;
import javax.swing.JFrame;

public class Drawing extends Canvas {
    public static void main(String[] args) {
        JFrame frame = new JFrame("I want a Donut!!");
        Canvas canvas = new Drawing();
        canvas.setSize(400, 400);
        frame.add(canvas);
        frame.pack();
        frame.setVisible(true);
    }

    public void paint(Graphics g) {
        getDonut(g);
    }

    public void getDonut(Graphics g){
        //donut
        g.setColor(Color.decode("#fad000"));
        g.fillOval(150, 150, 300, 300);
        g.setColor(Color.PINK);
        g.fillOval(175, 175, 250, 250);
        g.setColor(Color.WHITE);
        g.fillOval(250, 250, 100, 100);

        //sprinkles, yellow ones
        g.setColor(Color.YELLOW);
        g.fillRect(225, 225, 3, 20);
        g.fillRect(200, 300, 3, 20);
        g.fillRect(350, 350, 3, 20);
        g.fillRect(375, 250, 3, 20);
        g.fillRect(250, 374, 3 ,20);
        //white ones
        g.setColor(Color.WHITE);
        g.fillRect(300, 200, 3, 20);
        g.fillRect(225, 350, 3, 20);
        g.fillRect(400, 300, 3, 20);
        //black ones
        g.setColor(Color.BLACK);
        g.fillRect(300, 375, 3, 20);
        g.fillRect(215, 260, 3 ,20);
        g.fillRect(350, 200, 3, 20);
        g.fillRect(365, 280, 3, 20);
    }


}