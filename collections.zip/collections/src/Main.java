import java.util.*;

public class Main {

    public static void main(String[] args){
        Account acct ;
        //manage Accounts using a(n):
        //Arraylist
        List<Account> myBank = new ArrayList<Account>();
        myBank.add(new Account("tom", 324));
        myBank.add(new Account("jane", 834));
        myBank.add(new Account("mary", 78));
        myBank.add(new Account("mike", 325));
        myBank.add(new Account("angela", 66));
        myBank.add(new Account("anthony", 154));
        myBank.add(new Account("sabrina", 512));
        myBank.add(new Account("alan", 65));

        //print all -- for
        System.out.println("\nArrayList - for loop");
        for (Account i : myBank) {
            System.out.println( i );
        }
        //print all -- iterator
        System.out.println("\nArrayList - Iterator");
        Iterator alValue = myBank.iterator();
        while ( alValue.hasNext() ){  //as long as theres stuff in my arraylist
            System.out.println( alValue.next() );
        }

        //print in reverse
        // and deposit $20 to everyone < $100
        System.out.println("\nArrayList - reverse and +$20");
        for (int i = myBank.size() -1; i >= 0; i--) {
            if (myBank.get(i).getBalance() < 100){
                myBank.get(i).deposit(20);
            }
            System.out.println(myBank.get(i));
        }
        
        //duplicates??
        //yes, arraylist does not care about duplicates, and no modifications had to me made to the Account class
        myBank.add(new Account("anthony", 154));
        myBank.add(new Account("angela", 66));

        //TreeSet
        TreeSet myBankTree = new TreeSet<Account>();
        //tree doesnt know where or how to organize the tree
        //need to create a compareTo method (below)
        //to determine if Account <, >, or ==
        //duplicates not permitted in a tree - only one will output b/c of compareTo()
        myBankTree.add(new Account("tom", 324));
        myBankTree.add(new Account("jane", 834));
        myBankTree.add(new Account("mary", 78));
        myBankTree.add(new Account("mike", 325));
        myBankTree.add(new Account("angela", 66));
        myBankTree.add(new Account("anthony", 154));
        myBankTree.add(new Account("sabrina", 512));
        myBankTree.add(new Account("alan", 65));

        System.out.println("\n TreeSet - output");
        Iterator treeValue = myBankTree.iterator();
        while ( treeValue.hasNext() ) {
            System.out.println(treeValue.next());
        }



        //Stack
        Stack myBankStack = new Stack<Account>();
        myBankStack.push(new Account("tom", 324));
        myBankStack.push(new Account("jane", 834));
        myBankStack.push(new Account("mary", 78));
        myBankStack.push(new Account("mike", 325));
        myBankStack.push(new Account("angela", 66));
        myBankStack.push(new Account("anthony", 154));
        myBankStack.push(new Account("sabrina", 512));
        myBankStack.push(new Account("alan", 65));

        System.out.println("\nStack output - Iterator");
        Iterator stackValue = myBankStack.iterator();
        while ( stackValue.hasNext() ) {
            acct = (Account) stackValue.next();
            int thisBal = acct.getBalance();
            if (thisBal < 100) {
                acct.deposit(20);
            }
            System.out.println(acct);
        }

        //Queue
        Queue<Account> myQ = new ArrayDeque<Account>();

        for (Account i : myBank){
            myQ.add(i.clone());
        }

        for (Account jj : myQ){
            jj.withdraw(51);
            System.out.println(jj);
        }

        Iterator ii = myQ.iterator();
        while (ii.hasNext()){
            System.out.println( ii.next() );
        }

        //LinkedList
        
        List<Account> myLL = new LinkedList<Account>();
        myLL.addAll(  myBank );

        for ( Account i : myLL ){
            if (i.getBalance() < 300){
                i.deposit(250);
            }
            System.out.println(i);
        }

//        System.out.println("\n LinkedList - output");
//        Iterator llValue = myLL.iterator();
//        while ( llValue.hasNext() ) {
//            System.out.println(llValue.next());
//        }
        
        
    }


}
