public class Account implements Comparable<Account>{

    private String owner;
    private int balance;

    public Account ( String owner, int balance ) {
        this.owner = owner;
        this.balance = balance;
    }

    public void deposit(int amt) {
        balance += amt;
    }

    public void withdraw(int amt) {
        balance -= amt;
    }

    public int getBalance() {
        return balance;
    }

    public String getOwner() {
        return owner;
    }

    public String toString() {
        return "Account Class:   Owner: " + owner + "      Balance: " + balance;
    }

    //use owner name to compare to
    public int compareTo(Account acct) {
        return (owner.compareTo(acct.getOwner()));
    }

    public Account clone(){
        Account acct = new Account( owner, balance );
        return acct;
    }
}
