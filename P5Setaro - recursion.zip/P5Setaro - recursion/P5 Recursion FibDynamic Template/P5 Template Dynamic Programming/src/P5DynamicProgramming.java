
import javax.swing.JOptionPane;
import java.util.*;

public class P5DynamicProgramming {
    
    static long count  = 0; // of the number of invocatins
    static long[] values = new long[100]; //calculated fib values
    
    public static void main(String[] args) {
        long theTerm = 0;
        int n = 5;
        while(true) {   
            // input of n
            String nInput = JOptionPane.showInputDialog("Input a value to be "
                    + "calculated thats less than 92.");
            n = Integer.parseInt(nInput);
            if (n > 92){
                JOptionPane.showMessageDialog(null, "Error: n > 92!");
                System.exit(0);
            }
            
            // set count to to zero
            count = 0;
            
            // zero out the array;
            Arrays.fill(values, 0, values.length - 1, 0);
            
            theTerm = fibDynamic(n); // dynamic
            // output n, the Term, count
            System.out.println("Dynamic:       N: " + n + " " + "Answer: " + 
                    theTerm + " " + "Count: " + count);

            // non-dynamic
            // set count to to zero
            count = 0;
            
            // output n, the Term, count
            theTerm = fib(n); // non-dynamic
            System.out.println("Non-dynamic:   N: " + n + " " + "Answer: " + 
                    theTerm + " " + "Count: " + count);
            
            System.out.println();  //for readability
        }
        //hanoi(3, 1, 2, 3);
    }
    
    
    static long fibDynamic(int n){
        
        count++;
        
        
        if(n == 1 || n == 2) {// two base cases 
            return 1;
        }
        if (values[n-1] == 0) { //fib(n-1) not calculated
            long rp1 = fibDynamic(n-1);
            long rp2 = fibDynamic(n-2);
            values[n-1] = rp1;
            values[n-2] = rp2;
        }
        
        long gs = values[n-1] + values[n-2]; // reduced problem 2
        return gs;
    }
    
    static long fib(int n)
    {
        count ++;
        if(n == 1 || n == 2)// two base cases
        {
            return 1;
        }
        long rp1 = fib(n-1); // reduced problem 1
        long rp2 = fib(n-2);
        long gs = rp1 + rp2; // reduced problem 2
        return gs;
        
    }        
    
}
