import java.util.*;
import javax.swing.*;

public class P2ASetaro {


    public static void main(String[] args) {
        // Declare a Java API Stack object that can store Double objects
        Stack <Double> myStack = new Stack();
        
        
        // Accept the users input of the math String into the variable mathExpression
        String mathExpression = JOptionPane.showInputDialog("Enter your post "
                + "fixed expression");
        
        // Evaluate the math expression -- see code template in Exercise 21, pg 171
        String thisToken = "";
        StringTokenizer tokens = new StringTokenizer(mathExpression);
        while (tokens.hasMoreTokens()) {
            thisToken = tokens.nextToken();
              switch (thisToken) {
                case "*":
                    double tempMult1 = myStack.pop();
                    double tempMult2 = myStack.pop();
                    double mathMult = tempMult1 * tempMult2;
                    myStack.push(mathMult);                  
                    break;
                    
                case "/":
                    double tempDiv1 = myStack.pop();
                    double tempDiv2 = myStack.pop();
                    double mathDiv = tempDiv1 / tempDiv2;
                    myStack.push(mathDiv);                    
                    break;
                    
                case "+":
                    double tempAdd1 = myStack.pop();
                    double tempAdd2 = myStack.pop();
                    double mathAdd = tempAdd1 + tempAdd2;
                    myStack.push(mathAdd);
                    break;
                    
                case "-":
                    double tempSub1 = myStack.pop();
                    double tempSub2 = myStack.pop();
                    double mathSub = tempSub1 - tempSub2;
                    myStack.push(mathSub);
                    System.out.println(myStack.peek()); 
                    break;
                    
                default: 
                    myStack.push(Double.parseDouble(thisToken));
            }  
        }
        // Pop the stack and output the returned value
        JOptionPane.showMessageDialog(null, "Your answer is: " + myStack.pop());
    }
    
}
