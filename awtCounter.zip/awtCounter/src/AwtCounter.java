
import java.awt.*;
import java.awt.event.*;
import javax.swing.GroupLayout;


public class AwtCounter extends Frame implements ActionListener{
    
    private Label lblCounter;
    private TextField txtCounter;
    private Button btnInc;
    private Button btnReset;
    private int count;
    
    public AwtCounter(){
        count = 0;
        
        //label
        lblCounter = new Label("Counter");
        add(lblCounter);
        
        //Text
        txtCounter = new TextField(count + "", 10);
        txtCounter.setEditable(false);
        add(txtCounter);
        
        //Increment Button
        btnInc = new Button("Count");
        btnInc.setActionCommand("count");
        btnInc.addActionListener(this);
        add(btnInc);
        
        //Reset Button
        btnReset = new Button("Reset");
        btnReset.addActionListener(this);
        btnReset.setActionCommand("reset");
        add(btnReset);
        
        
        //frame
        setSize(350, 80);
        setLayout(new FlowLayout());
        setTitle("Lady Gaga counts");
        setVisible(true);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we){
                
                System.exit(0);
                
            }
        });
        
    }
    
    public void actionPerformed(ActionEvent evt){
        
        if (evt.getActionCommand().equals("count")){
            count++;
            txtCounter.setText(count + "");
        }
        
        if (evt.getActionCommand().equals("reset")){
            count = 0;
            txtCounter.setText(count + "");
        }
        
    }

    public static void main(String[] args) {
        
        new AwtCounter();
    }
    
}
