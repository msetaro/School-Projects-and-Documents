public class Main {

    public static void main(String[] args) {
	    Integer [] nums = { 34, 657, 54, 56, 67, 8, 32, 696 };
	    String[] names = { "toni", "anne", "bryan", " jordon", "dan" };

	    for ( int i: nums )
            System.out.print( i + " ");

    }
    public static void sort( int[] arr ){
        //bubble sort
        for ( int j = arr.length - 1; j >= 0; j--)
            for ( int i = 0; i < arr.length - 1; i++ )
                if ( arr[i] > arr[i+1] ){
                    int t = arr[i];
                    arr[i] = arr[i+1];
                    arr[i+1] = t;
        }
    }

    public static String[] sortString( String[] arr){
        for (int j = arr.length-1; j>= 0; j--)
            for (int i = 0; i < arr.length -1; i++)
                if (arr[i].compareTo(arr[i+1]) > 0){
                    String t = arr[i];
                    arr[i] = arr[i+1];
                    arr[i+1] = t;
                }
        return arr;
    }

    public static <T extends Comparable<T>> T[] sortIt( T[] arr){
        for (int i =  arr.length-1; i>0; i--)
            for (int j=0; j<i; j++)
                if (arr[j].compareTo(arr[j+1]) > 0) {
                    T t = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = t;
                }
        return arr;
    }

    public static <T> T sortMethod(T arr){
        return arr;
    }

}
