
public class SinglyLinkedList {
    
    private Node h;
    
    public SinglyLinkedList(){
        
        Node t  = new Node();
        h = t;
        
    }
    
    public boolean insert (StudentListings newListing){
         Node n = new Node();
         n.l = newListing.deepCopy();
         if (h.next == null) {  //If no node is in the structure
             n.back = h;
             h.next = n;
             return true;
         }
         else if (h.next.l.compareTo(n.l.getKey()) > 0) {  //If node to insert is less than first node in list, place before
             h.next.back = n;
             n.next = h.next;
             h.next = n;
             n.back = h;
             return true;
         }
         else {   //otherwise scan thru and find insertion point
             Node p = h.next;
             Node q = h.next.next;
             while ( q!= null ) {
                 if ( q.l.compareTo(n.l.getKey()) >= 0) {
                    n.back = p;
                    n.next = q;
                    q.back = n;
                    p.next = n;
                    return true;
                 }
                 p = p.next;
                 q = q.next;
             }
             n.back = p;
             p.next = n;  //places node at end if it doesnt find a value in the list it is less than
             return true;
         }
                
    }
    
    public StudentListings fetch(String targetKey){
        Node p = h.next;
        while (p != null && !(p.l.compareTo(targetKey) == 0)){
            p = p.next;
        }
        if (p != null)
            return p.l.deepCopy();
        else 
            return null;
        
    }
    
    public boolean delete(String targetKey){
        Node q = h;
        Node p = h.next;
        while (p != null && !(p.l.compareTo(targetKey) == 0)){
            q = p;
            p = p.next;
        }
        if (p != null){
            q.next = p.next;
            return true;
        }
        else
            return false;
    }
    
    public boolean update(String targetKey, StudentListings newListing){
        if (delete(targetKey) == false)
            return false;
        else if(insert(newListing) == false)
            return false;
        return true;
    }
    
    public void showAll(){
        Node p = h.next;
        while (p != null){
            System.out.println(p.l.toString());
            p = p.next;
        }
    }
    
    public void showAllBackwards() {
        Node p = h.next;
        Node q = h.next;
        while (q.next != null){
            q = q.next;
        } //when completed, at the end of the linked list
        while (q != p) {
            System.out.println(q.l.toString());
            q = q.back;
        }
        System.out.println(q.l.toString());
    }
    
    public class Node{
        private StudentListings l;
        private Node next;
        private Node back;
        
        public Node() {
        }
        
    }
            
}
