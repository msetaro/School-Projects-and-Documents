
import javax.swing.JOptionPane;
public class StudentListings {
    // Exercise 19, chapter 2, pg 1212
    // Use Fig 2.28
    //     Change data members
    //     Change node to StudentListings
    //     Adjust parameters and arguments
    //     Remove setAddress
   private String name;  // key field
   private String address;
   private String number;
   
   public StudentListings(String n, String a, String num ){
      name = n;
      address = a;
      number = num;
  }
   
   public String toString( ){
       return("Name is " + name +
       "\nAddress is " + address +
       "\nNumber is " + number + "\n");
   }
   
   public StudentListings deepCopy( ){
      StudentListings clone = new StudentListings(name, address, number);
      return clone;
   }
   
   public int compareTo(String targetKey){
       return(name.compareTo(targetKey));
   }
   
   public void inputNode( ){
      name = JOptionPane.showInputDialog("Enter a name");
      address = JOptionPane.showInputDialog("Enter an address");
      number = JOptionPane.showInputDialog("Enter a number");
   }
  
   public String getKey(){
       return name;
   }

}
