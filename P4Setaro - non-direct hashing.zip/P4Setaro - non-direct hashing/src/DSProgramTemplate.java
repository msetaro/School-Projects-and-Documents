
import javax.swing.JOptionPane;

public class DSProgramTemplate 
{
    public static void main(String[] args) 
    {
      // declarations: aString, maxNodes, initialNodes, aStudentListing, choice, ...
      LQHashed ds;
      int choice;
      
      // Ask for the maximum nodes that will be in the structure and parse input
      String size = JOptionPane.showInputDialog("How many total users do you have?");
      int num = Integer.parseInt(size);
      
      
      
      // Ask for the initial nodes that will be in the structure and parse input
      String inputSize = JOptionPane.showInputDialog("How many users do you wish"
              + " to add to the data structure?");
      int inputNum = Integer.parseInt(inputSize);
      
      //Ask for the node width
      String nodeWidth = JOptionPane.showInputDialog("What is the width of your node?");
      int nodeW = Integer.parseInt(nodeWidth);
      
      // Declare the data structure object 
      ds = new LQHashed(num, nodeW);
      
      // for loop to input and insert initial nodes into the structure
      for (int i = 0; i < inputNum; i++){
          StudentListings newStudent;
          String nameInput = JOptionPane.showInputDialog("What is the name of "
                  + "the student?");
          String addressInput = JOptionPane.showInputDialog("What is the address"
                  + " of the student?");
          String numInput = JOptionPane.showInputDialog("What is the ID number "
                  + "of the student?");
          
          newStudent = new StudentListings(nameInput, addressInput, numInput);
          
          ds.insert(newStudent);
          
      }
     
      // output the menu, and parse the menu choice
        String nextAction = JOptionPane.showInputDialog("Please select and option:"
              + " \n 1: insert \n 2: fetch \n 3: delete \n 4: update "
              + "\n 5: show all \n 6: exit");
        choice = Integer.parseInt(nextAction);
     
      // while (choice != 6)
      // {  switch statement to perform menu choice 
      //    {
      //        Be sure to inform user
      //        of success: output the fetched node, output "node deleted", ...)
      //        or failure: output "node not in structure", or "structure full"
      //    }
      //    output the menu, and parse the menu choice
      // } 
      
      while (choice != 6){
          switch (choice){
              case 1: StudentListings newStudent;
                      String nameInput = JOptionPane.showInputDialog("What is the name of "
                            + "the student?");
                      String addressInput = JOptionPane.showInputDialog("What is the address"
                            + " of the student?");
                      String numInput = JOptionPane.showInputDialog("What is the ID number "
                            + "of the student?");
          
                      newStudent = new StudentListings(nameInput, addressInput, numInput);
          
                      ds.insert(newStudent);
                     
                      choice = 0;
                      break;
              case 2: String search = JOptionPane.showInputDialog("What would "
                      + "you like to fetch? (enter a name)");
                      StudentListings found = ds.fetch(search);
                      if (found == null){
                          JOptionPane.showMessageDialog(null, "Node not found!");
                      }
                      else
                          JOptionPane.showMessageDialog(null, ds.fetch(search));
                      choice = 0;
                      break;
              case 3: String delete = JOptionPane.showInputDialog("What would "
                      + "you like to delete? (enter a string)");
                      ds.delete(delete);
                      choice = 0;
                      break;
              case 4: String update = JOptionPane.showInputDialog("What would "
                      + "you like to update? (enter a name");
                      String nameUpdate = JOptionPane.showInputDialog("What is the name of "
                            + "the student?");
                      String addressUpdate = JOptionPane.showInputDialog("What is the address"
                            + " of the student?");
                      String numUpdate = JOptionPane.showInputDialog("What is the ID number "
                            + "of the student?");
                      StudentListings updateStudent;
                      updateStudent = new StudentListings(nameUpdate, addressUpdate, numUpdate);
                      boolean test = ds.update(update, updateStudent);
                      if ( test == true ){
                          JOptionPane.showMessageDialog(null, "Node updated successfully!");
                      }
                      else
                         JOptionPane.showMessageDialog(null, "Node update failed!");
                      choice = 0;
                      break;
              case 5: ds.showAll();
                      JOptionPane.showMessageDialog(null, "Check the console for"
                              + " all the users");
                      choice = 0;
                      break;
              case 6: System.exit(0);
                      break;
              default: String next = JOptionPane.showInputDialog("Please select and option:"
                            + " \n 1: insert \n 2: fetch \n 3: delete \n 4: update "
                            + "\n 5: show all \n 6: exit");
                            choice = Integer.parseInt(next);
                            break;
          }
      }
    }
}
