
public class LQHashed {
    int N;
    int n = 0;  //the number of nodes in the structure
    int defaultQuotient = 9967; //the default 4k+3 prime
    int nd = 0;
    int w;
    double plf;
    double lf = (double)n / (double)N;
    int nops;
    int naa;
    double cd = 1 / (1+4 / (w*lf));
    double loadingFactor = 0.75;
    StudentListings deleted; //the dummy node, v2 (v1 = null)
    private StudentListings[] data; //the primary storage array
    
    public LQHashed(int length , int w){
        this.w = w;
        int pct = (int)((1.0 / loadingFactor - 1) * 100.0);
        N = fourKPlus3(length, pct);
        data = new StudentListings[N];
        deleted = new StudentListings("","","");
        for (int i = 0; i < N; i++){
        data[i] = null;
    }
    }//end of constructor
    
    public boolean insert(StudentListings newListing){
        nops++;
        boolean noError;
        boolean hit = false;
        boolean success;
        int pass, q, offset, ip;
        int pk = stringToInt(newListing.getKey());
        if((((double) n) / N) <= loadingFactor){ //insert node
            pass = 0;
            q = pk / N;
            offset = q;
            ip = pk % N;
            if ( q % N == 0){
                offset = defaultQuotient;
            }
            while(pass < N){
                naa++;
                if(data[ip] == null || data[ip] == deleted){
                    hit = true;
                    break;
                }
                ip = (ip + offset) % N;
                pass = pass + 1;
            }
            if(hit == true){  //insert the node
                if(data[ip] == deleted)
                    nd--;
                data[ip] = newListing.deepCopy();
                n++;
                plf = (n + nd) / ((double) N);
                if (plf > 0.75){
                    expand(N);
                    nd = 0;
                }
                outputStats();
                return noError = true;
            }
            else{
                outputStats();
                return noError = false;
            }
        }
        //success = expand( fourKPlus3(N*2, 33));
        //if (success == false){
            //outputStats();
            
        //}
        //return noError = false;
        else
            return noError = false;
        
    }//end insert method
    
    public StudentListings fetch(String targetKey){
        nops++;
        boolean noError;
        boolean hit = false;
        int pass, q, offset, ip;
        int pk = stringToInt(targetKey);  //preprocesses the key
        pass = 0;
        q = pk / N;
        offset = q;
        ip = pk % N;
        if (q % N == 0)
            offset = defaultQuotient;
        while(pass < N){
            naa++;
            if(data[ip] == null){ //node not in structure
               break;
            }
            if(data[ip].compareTo(targetKey) == 0){  //node found
                hit = true;
                break;
            } 
            ip = (ip + offset) % N;
            pass = pass + 1;
        }
        if(hit == true){  //return a deep copy of the node
            outputStats();
            return data[ip].deepCopy();
        }
        else
            outputStats();
            return null;
    }
    
    public boolean delete(String targetKey){
        nops++;
        boolean noError;
        boolean hit = false;
        int pass, q, offset, ip;
        int pk = stringToInt(targetKey);
        pass = 0;
        q = pk / N;
        offset = q;
        ip = pk % N;
        if (q % N == 0){
            offset = defaultQuotient;
        }
        while(pass < N){
            naa++;
            if(data[ip] == null)
                break;
            if(data[ip] .compareTo(targetKey) == 0){  //node found
                hit = true;
                break;
            }
            ip = (ip + offset) % N;  //collision occured
            pass = pass + 1;
        }
        if(hit == true){  //delete the node
            data[ip] = deleted;
            nd++;
            n--;
            outputStats();
            return noError = true;
        } 
        else{
            outputStats();
            return noError = false;
        }
    }

    public boolean update(String targetKey, StudentListings newListing){
        if(delete(targetKey) == false)
            return false;
        else if(insert(newListing) == false)
            return false;
        return true;
    }  
    
    public void showAll(){
        for(int i = 0; i < N; i++){
            if (data[i] != null && data[i] != deleted)
                System.out.println(data[i].toString());
        }
    }
        
    public static int fourKPlus3(int n, int pct){
        boolean fkp3 = false;
        boolean aPrime = false;
        int prime, highDivisor, d;
        double pctd = pct;
        prime = (int)(n * (1.0 + (pctd / 100.0)));
      
        if(prime % 2 == 0)
            prime = prime + 1;
        while (fkp3 == false){
            while(aPrime == false){
                highDivisor = (int)(Math.sqrt(prime) + 0.5);
                for(d = highDivisor; d > 1; d--){
                    if (prime % d == 0)
                        break;  
                }
                if(d != 1)  //prime not found
                    prime = prime + 2;
                else
                    aPrime = true;
            }
            if ((prime - 3) % 4 == 0)
                fkp3 = true;
            else {
                prime = prime + 2;
                aPrime = false;
            }
        }  
        return prime;
    }
    
    public static int stringToInt(String aKey){
        int pseudoKey = 0;
        int n = 1;
        int cn = 0;
        char c[] = aKey.toCharArray();
        int grouping = 0;
        while (cn < aKey.length()) {
            grouping = grouping << 8;
            grouping = grouping + c[cn];
            cn = cn + 1;
            if(n==4 || cn == aKey.length()){
                pseudoKey = pseudoKey + grouping;
                n = 0;
                grouping = 0;
            }
            n = n + 1;
        }
        return Math.abs(pseudoKey);
                
    }
    
    private boolean expand(int newSize){
        StudentListings[] temp;
        temp = data;
        data = new StudentListings[newSize];
        if (data == null){
            data = temp;
            return false; //couldnt expand
        }
        N = newSize;
        for (int i = 0; i < temp.length; i++){
            if (temp[i] != null && temp[i] != deleted)
                insert (temp[i]);
        }   
        return true;
    }
    
    private void outputStats(){
        System.out.println("Pseudo loading factor: " + (n + nd) / ((double) N) );
        System.out.println("Loading factor: " + n/((double) N));
        System.out.println("Current density: " + cd);
        System.out.println("Average search length: " + naa/((double) nops));
        System.out.println();
        System.out.println();
        
    }
}
    
    
    
