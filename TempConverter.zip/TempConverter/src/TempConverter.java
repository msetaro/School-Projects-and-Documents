
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import javax.swing.*;



public class TempConverter extends Frame implements ActionListener{
    
    private Label directions;
    private Label test;
    private TextField inputTemp;
    private JRadioButton toFaren;
    private JRadioButton toCelc;
    private JRadioButton cToKelvin;
    private JRadioButton fToKelvin;
    private Button convert;
    private ButtonGroup group;
    
    
    public TempConverter() {
        //label
        directions = new Label("Input a temperature:");
        add(directions);
        
        //text
        //input
        inputTemp = new TextField(10);
        add(inputTemp);
        
        //radio buttons
        toFaren = new JRadioButton("Celsius to Fahrenheit");
        toFaren.setSelected(true);
        toCelc = new JRadioButton("Fahrenheit to Celsius");
        cToKelvin = new JRadioButton("Celsius to Kelvin");
        fToKelvin = new JRadioButton("Fahrenheit to Kelvin");
        add(toFaren);
        add(toCelc);
        add(cToKelvin);
        add(fToKelvin);
       
        //group them
        group = new ButtonGroup();
        group.add(toCelc);
        group.add(toFaren);
        group.add(cToKelvin);
        group.add(fToKelvin);
        
        
        //test for padding ( add an empty label to the screen b/c the button wasnt
        //where I wanted it to be
        test = new Label("");
        add(test);
        
        //BUTTON
        convert = new Button("Convert");
        convert.addActionListener(this);
        add(convert);


        //frame
        setSize(250,200);
        setLayout(new FlowLayout());
        setTitle("Temp Converter");
        setVisible(true);
        
        //close w x button
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we){
                
                System.exit(0);
                
            }
        });
    }
    
    public void actionPerformed(ActionEvent evt){
        
        if (toFaren.isSelected()){
            JOptionPane.showMessageDialog(null, inputTemp.getText() + 
                    "°C   is   " + cToFahrenheit(Double.parseDouble(inputTemp.getText())) 
                    + "°F", "Celsius To Fahrenheit", JOptionPane.PLAIN_MESSAGE);
        }
        
        if (toCelc.isSelected()){
            JOptionPane.showMessageDialog(null, inputTemp.getText() + 
                    " °F   is  " +fToCelcius(Double.parseDouble(inputTemp.getText())) 
                    + " °C", "Fahrenheit to Celsius", JOptionPane.PLAIN_MESSAGE);
        }
        
        if (cToKelvin.isSelected()){
            JOptionPane.showMessageDialog(null, inputTemp.getText() +
                    " °C   is   " + (Double.parseDouble(inputTemp.getText()) + 273.15) + " °K"
            , "Celsius to Kelvin" , JOptionPane.PLAIN_MESSAGE);
        }
        
        if (fToKelvin.isSelected()){
            JOptionPane.showMessageDialog(null, inputTemp.getText() + 
                    " °F   is   " + fToKelvin(Double.parseDouble(inputTemp.getText()))
            + " °K", "Fahrenheit to Kelvin", JOptionPane.PLAIN_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new TempConverter();
    }
    
    public double fToCelcius(double temp){
        double fx = (temp - 32) * 5/9;
        return fx;
    }
    
    public double cToFahrenheit(double temp){
        double fx = (temp * 9/5) + 32.0;
        return fx;
    }
    
    public double fToKelvin(double temp){
        double toC = fToCelcius(temp);
        return toC + 273.15;
    }
    
}
