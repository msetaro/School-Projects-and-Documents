import matplotlib.pyplot as plt
import csv
# import csv data for XMR, ETH, and BCH
# XMR
fname = "XMR-USD.csv"

xmrData = []

with open(fname, 'r') as data:
    for line in csv.reader(data):
        xmrData.append(line)
data.close()

# ETH
fname = "ETH-USD.csv"
ethData = []
with open(fname, 'r') as data:
    for line in csv.reader(data):
        ethData.append(line)
data.close()

# BCH
fname = "BCH-USD.csv"
bchData = []
with open(fname, 'r') as data:
    for line in csv.reader(data):
        bchData.append(line)
data.close()


# opening prices of XMR?
# takes the second thing in my list and converts it to a float then stores it in a list
xmrOpen = []
for i in xmrData:
    xmrOpen.append(float(i[1]))

# opening price of ETH
ethOpen = []
for i in ethData:
    ethOpen.append(float(i[1]))

# opening price of BCH
bchOpen = []
for i in bchData:
    bchOpen.append(float(i[1]))


xLabels = ['Sept. \'19', 'Oct. \'19', 'Nov. \'19', 'Dec. \'19', 'Jan. \'20', 'Feb. \'20', 'Mar. \'20', 'Apr. \'20', 'May \'20',
           'Jun. \'20', 'Jul. \'20', 'Aug. \'20', 'Sept. \'20']
deviations = [1, 26, 54, 88, 119, 150, 181, 212, 243, 274, 305, 336, 367]


# pyplot stuff
plt.plot(xmrOpen, label="XMR", color="#ffbf00")
plt.plot(ethOpen, label="ETH", color="#8859ff")
plt.plot(bchOpen, label="BCH", color="#2ded4d")
plt.minorticks_on()
plt.xticks(deviations, xLabels, rotation='vertical')
plt.title("Three cryptocurrencies from 9/2019 - 9/2020")
plt.xlabel("Month")
plt.ylabel("Price in USD ($)")

plt.legend()
plt.show()

