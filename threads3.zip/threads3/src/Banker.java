public class Banker {

    int balance = 1000;
    String owner;



    synchronized void withdraw( int amt ) {    //don't interrupt it
        System.out.println("entered withdraw()");
        while (balance < amt) {  //not enough money
            //wait for enough deposits to handle the withdraw
            System.out.println("negative balance - current balance: " + balance);
            try{
                wait();
            }
            catch (Exception e ){}
        }
        //when i get out of here - i have enough
        balance -= amt;
        System.out.println("withdraw done - balance: " + balance + "amt: " + amt );
    }

    synchronized void deposit( int amt ) {
        System.out.println("entered deposit()" + balance);
        balance += amt;
        System.out.println("balance after deposit: " + balance);
        notify();
    }






}

