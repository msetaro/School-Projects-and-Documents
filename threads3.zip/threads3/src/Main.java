public class Main {

    public static void main(String[] args) {
	    Banker myB = new Banker();

	    new Thread() {
	        public void run() {
	            myB.withdraw(2000);
            }
        }.start();

	    new Thread() {
	        public void run() {
	            myB.deposit(300);
            }
        }.start();

    }
}
